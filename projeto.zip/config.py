IP = "mongodb://localhost:27017/"
DATABASE = "test"
TABELA = 'anuncios'
VERSAO = 1.5